import { Button } from "@material-tailwind/react";
import { Link } from "react-router-dom";

const Logout = () => {
  return (
    <div className="flex w-screen h-screen items-center justify-center gap-10 flex-col">
      You have successfully Logged out. Thank you !
      <Link to={"/login"} replace>
        <Button>Login Back</Button>
      </Link>
    </div>
  );
};

export default Logout;
