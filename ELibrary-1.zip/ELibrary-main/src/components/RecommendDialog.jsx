import { XMarkIcon } from "@heroicons/react/24/outline";
import {
    Button,
  Dialog,
  DialogBody,
  DialogHeader,
  Input,
} from "@material-tailwind/react";
import React from "react";

const RecommendDialog = ({ open, handleOpen }) => {
  return (
    <Dialog open={open} handler={handleOpen} size="xs">
      <DialogHeader className="flex items-center justify-between">
        <p>Recommend This Book !</p>
        <XMarkIcon className="h-5 w-5 cursor-pointer" onClick={handleOpen} />
      </DialogHeader>
      <DialogBody className="w-full">
        <Input type="email" label="Enter Email" />
        <Button className="mt-5">Recommend !</Button>
      </DialogBody>
    </Dialog>
  );
};

export default RecommendDialog;
