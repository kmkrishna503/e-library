/* eslint-disable react/prop-types */
import axios from "axios";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Button, Card
} from "@material-tailwind/react";

const Quiz = ({ bookId }) => {
  const form = useForm({
    mode: "onChange",
  });
  const { register, handleSubmit, formState } = form;
  const { isSubmitSuccessful } = formState;
  const [questions, setQuestions] = useState([]);
  const [score, setScore] = useState(0);
  const getQuizQuestions = async () => {
    const res = await axios.get(
      `http://localhost:3000/quiz/questions/${bookId}`
    );
    setQuestions(res.data.questions);
  };
  useEffect(() => {
    getQuizQuestions();
  }, [bookId]);

  const evaluateQuiz = async (data) => {
    console.log(data);
    const answers = Object.values(data);
    const correctAnswers = questions.map((item) => item.correctAnswer);
    let correctMatches = 0;
    for (let i = 0; i < answers.length; i++) {
      if (answers[i] === correctAnswers[i]) {
        correctMatches++;
      }
    }
    console.log(correctMatches)
    setScore(correctMatches * 10)
  };
  
  if (isSubmitSuccessful) {
    return (
      <div className="flex items-center justify-center p-10">
        <Card className="p-10 text-black">
          <p className="font-semibold text-xl">Submit Successful</p>
          <p>Your Score : {score}</p>
        </Card>
      </div>
    );
  }
  return (
    <Card className="my-5 pb-5">
      <div className="text-center text-black font-semibold text-lg my-4">
        Quiz Questions
      </div>
      <div className="px-6">
        <form
          onSubmit={handleSubmit(evaluateQuiz)}
          className="flex flex-col gap-10"
        >
          {questions?.map((item, index) => {
            return (
              <div key={index}>
                <p>
                  {index + 1} {item?.question}
                </p>
                <div className="grid grid-cols-4 md:grid-cols-2 lg:grid-cols-8 mt-3 items-center">
                  {item?.options.map((option, optionIndex) => {
                    return (
                      <>
                        <input
                          type="radio"
                          key={optionIndex}
                          name={item.question} // Use a unique name for each option
                          label={option}
                          value={option}
                          {...register(item.questionId)}
                          className="h-4"
                        />
                        {option}
                      </>
                    );
                  })}
                </div>
              </div>
            );
          })}

          <Button type="submit" className="w-fit mx-auto">
            Submit Quiz
          </Button>
        </form>
      </div>
    </Card>
  );
};

export default Quiz;
