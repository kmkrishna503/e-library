import Chart from "./Chart";
import DashboardCard from "./DashboardCard";
import PointsTable from "./PointsTable";

const DashBoard = () => {
  return (
    <main className="flex-1 px-3 ">
      <section className="flex flex-col lg:grid lg:grid-cols-3 gap-6 mb-4justify-between">
        <DashboardCard
          heading={"Total Points"}
          text={"Points earned by subscriptions"}
          value={200}
          color={"red"}
        />
        <DashboardCard
          heading={"Books Subscribed"}
          text={"Number of books read by user"}
          value={2}
          color={"blue"}
        />
        <DashboardCard
          heading={"Active Subscriptions"}
          text={"Number of books currently reading"}
          value={2}
          color={"green"}
        />
        <PointsTable />
        <Chart />
      </section>
    </main>
  );
};

export default DashBoard;
