import React, { useEffect, useState } from "react";
import { useParams } from "react-router";
import axios from "axios";
import { Button, Card, CardBody, CardHeader } from "@material-tailwind/react";
import RecommendDialog from "./RecommendDialog";
const Book = () => {
  const { id } = useParams();
  const [book, setBook] = useState(null);
  const [readMore, setReadMore] = useState(true);
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(!open);
  useEffect(() => {
    const getBook = async () => {
      const response = await axios.get(`http://localhost:3000/books/${id}`);
      const book = await response.data;
      setBook(book);
    };
    getBook();
  }, [id]);
  console.log(book);
  return (
    <>
      <section className="w-full px-3">
        <Card className="w-full p-5 mt-5">
          <CardHeader
            floated={false}
            shadow={false}
            className="font-semibold text-lg bg-inherit text-inherit text-center"
          >
            {book?.name}
          </CardHeader>
          <CardBody className="grid grid-cols-4 text-white   bg-gray-900 p-4 rounded-md">
            <section className="font-medium flex gap-2 flex-col">
              <p>Author : {book?.author}</p>
              <p>Category : {book?.Category}</p>
              <p>Publisher : {book?.Publisher}</p>
              <p>Date Published : {book?.["Date Published"]}</p>
              <p>Points : {book?.points}</p>
            </section>
            <section className="col-span-2 flex flex-col justify-between">
              Harry Potteris a series of sevenfantasy novelswritten by British
              author J. K. Rowling. The novels chronicle the lives of a
              youngwizard,Harry Potter, and his friendsHermione GrangerandRon
              Weasley, all of whom are students atHogwarts School of Witchcraft
              and Wizardry. The mainstory arcconcerns Harry's struggle
              againstLord Voldemort, a dark wizard who intends to become
              immortal, overthrow the wizard governing body known as theMinistry
              of Magicand subjugate all wizards andMuggles(non-magical people).
              <div className="flex w-full justify-between items-center">
                <p
                  className="p-2 cursor-pointer text-blue-300 hover:underline transition-all duration-300 ease-in-out"
                  onClick={() => setReadMore(!readMore)}
                >
                  {readMore ? "Read more" : "Collapse"}
                </p>
                <p
                  className="p-2 cursor-pointer text-blue-300 hover:underline transition-all duration-300 ease-in-out"
                  onClick={handleOpen}
                >
                  Recommend to a Colleague
                </p>
              </div>
            </section>
            <section>
              <img
                src={book?.img}
                alt={book?.name}
                className="h-60 w-full object-contain"
              />
            </section>
          </CardBody>
        </Card>
        <Card
          className={`mt-5 text-white bg-gray-900 ${
            readMore ? "hidden" : "block"
          }`}
        >
          <CardBody>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore,
            explicabo provident at nemo sequi, laudantium sapiente fugit odio
            consequatur cumque dicta rerum laboriosam id odit reiciendis aut
            voluptatum voluptatibus. Reprehenderit corporis praesentium labore
            illum. Ullam optio possimus nesciunt doloremque nisi perspiciatis.
            Nulla nam doloremque totam, optio eaque id adipisci dolores, esse
            iste incidunt sit est nesciunt cupiditate? Qui velit unde laudantium
            impedit quod molestiae doloremque voluptas sunt possimus architecto
            ipsam earum delectus asperiores, explicabo numquam. Dicta minima
            magni placeat natus quae recusandae animi quasi molestias saepe,
            quia distinctio exercitationem ad architecto, maiores fuga
            accusantium, vitae delectus sit deserunt harum! Tempore pariatur at
            dignissimos consectetur mollitia sequi quibusdam reiciendis repellat
            aliquam delectus excepturi officiis iusto, sunt, earum id rem totam
            modi quos doloribus aliquid blanditiis doloremque aut deleniti! Ad,
            voluptatum aliquam animi earum odio a ab, magni possimus quod
            pariatur molestiae consequuntur incidunt labore cupiditate iste unde
            facere dolorem harum alias quaerat enim? Veniam libero amet deserunt
            eligendi asperiores a aperiam molestiae quidem voluptas suscipit
            provident et consequatur deleniti excepturi obcaecati pariatur eaque
            ab, doloremque iste quos at animi optio omnis laborum? Ad quas
            blanditiis dolore voluptas id fuga! Aut ad voluptatibus eos
            exercitationem quis quod dignissimos consequuntur labore iure
            dolores.
          </CardBody>
        </Card>
      </section>
      <RecommendDialog open={open} handleOpen={handleOpen} />
    </>
  );
};

export default Book;
