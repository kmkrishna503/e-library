import { Card, List, ListItem, ListItemPrefix } from "@material-tailwind/react";
import { PresentationChartBarIcon, InboxIcon } from "@heroicons/react/24/solid";
import {
  BanknotesIcon,
  MagnifyingGlassIcon,
  PowerIcon
} from "@heroicons/react/24/outline";
import { Link } from "react-router-dom";
import {CgSandClock} from "react-icons/cg"
export function SideBar() {
  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn");
  }
  return (
    <Card className="fixed hidden lg:block z-[9998] h-screen max-w-[16rem] p-4 shadow-xl shadow-blue-gray-900/5 bg-gray-900 rounded-none text-white font-bold">
      <List className="pt-[5rem]">
        <Link to={"/"}>
          <ListItem className="text-white">
            <ListItemPrefix>
              <PresentationChartBarIcon className="h-5 w-5" />
            </ListItemPrefix>
            Dashboard
          </ListItem>
        </Link>
        <Link to={"/ebooks"}>
          <ListItem className="text-white">
            <ListItemPrefix>
              <MagnifyingGlassIcon className="h-5 w-5" />
            </ListItemPrefix>
            Surf E-books
          </ListItem>
        </Link>
        <Link to={"/subscriptions"}>
          <ListItem className="text-white">
            <ListItemPrefix>
              <CgSandClock className="h-5 w-5" />
            </ListItemPrefix>
            Take Quiz
          </ListItem>
        </Link>
        
      </List>
    </Card>
  );
}
