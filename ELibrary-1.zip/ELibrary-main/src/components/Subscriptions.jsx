import {
  Card,
  CardBody,
  CardHeader,
  Typography,
} from "@material-tailwind/react";
import axios from "axios";
import { useEffect, useState } from "react";
import Quiz from "./Quiz";

const TABLE_HEAD = [
  "E-Book ID",
  "E-Book Name",
  "Subscription Date",
  "Subscription ID",
  "Quiz",
];
const Subscriptions = () => {
  const [attempt, setAttempt] = useState(false);
  const [bookId, setBookId] = useState(null);
  const [subscriptions, setSubscriptions] = useState([]);
  useEffect(() => {
    const fetchSubscriptions = async () => {
      const response = await axios.get("http://localhost:3000/subscriptions");
      const data = await response.data;
      setSubscriptions(data);
    };
    fetchSubscriptions();
  }, []);
  return (
    <div className="flex flex-col w-full px-3">
      <Card className="h-fit w-full px-3 ">
        <CardHeader
          floated={false}
          shadow={false}
          className="text-center font-semibold text-gray-800 text-lg mb-2"
        >
          Select From Your Active Subscription
        </CardHeader>
        <CardBody className="overflow-auto">
          <table className="w-full min-w-max table-auto text-left">
            <thead>
              <tr>
                {TABLE_HEAD.map((head) => (
                  <th
                    key={head}
                    className="border-b border-blue-gray-100 bg-blue-gray-50 p-4"
                  >
                    <Typography
                      variant="small"
                      className="text-gray-800 font-semibold  leading-none"
                    >
                      {head}
                    </Typography>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {subscriptions?.map((subscription, index) => (
                <tr key={index} className="even:bg-blue-gray-50/50">
                  <td className="p-4">
                    <Typography
                      variant="small"
                      color="blue-gray"
                      className="font-normal"
                    >
                      {subscription?.["E-Book ID"]}
                    </Typography>
                  </td>
                  <td className="p-4">
                    <Typography
                      variant="small"
                      color="blue-gray"
                      className="font-normal"
                    >
                      {subscription?.["E-Book Name"]}
                    </Typography>
                  </td>
                  <td className="p-4">
                    <Typography
                      variant="small"
                      color="blue-gray"
                      className="font-normal"
                    >
                      {subscription?.["Subscription Date"]}
                    </Typography>
                  </td>
                  <td className="p-4">
                    <Typography
                      variant="small"
                      color="blue-gray"
                      className="font-normal"
                    >
                      {subscription?.["Subscription ID"]}
                    </Typography>
                  </td>
                  <td className="p-4">
                    <Typography
                      variant="small"
                      color="blue-gray"
                      className="font-normal cursor-pointer text-blue-500"
                      onClick={() => {
                        setBookId(subscription["E-Book ID"]);
                        setAttempt(true);
                      }}
                    >
                      Attempt Quiz
                    </Typography>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardBody>
      </Card>
      <div className={`${attempt ? "block" : "hidden"}`}>
        <Quiz bookId={bookId} />
      </div>
    </div>
  );
};
export default Subscriptions;
