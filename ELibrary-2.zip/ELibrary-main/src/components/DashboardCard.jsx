/* eslint-disable react/prop-types */
import { Card, CardBody, Typography } from "@material-tailwind/react";
import { CircularProgressbar, buildStyles } from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";

const DashboardCard = ({ heading, text, value, color }) => {
  return (
    <Card className="max-h-fit">
      <CardBody>
        <Typography variant="h4" color="blue-gray" className="mb-2 text-center">
          {heading}
        </Typography>
        <div className="flex items-center justify-between gap-2">
          <Typography>{text}</Typography>
          <div className="w-[100px] h-[80px]">
            <CircularProgressbar
              maxValue={value}
              minValue={value}
              styles={buildStyles({
                strokeLinecap: "butt",
                pathColor: `${color}`,
                textColor: "#000",
                trailColor: "#d6d6d6",
                backgroundColor: "#3e98c7",
              })}
              value={value}
              text={`${value}`}
              s
            />
          </div>
        </div>
      </CardBody>
    </Card>
  );
};

export default DashboardCard;
