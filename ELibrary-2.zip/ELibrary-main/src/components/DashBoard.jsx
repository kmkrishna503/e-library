import { Link } from "react-router-dom";
import Chart from "./Chart";
import DashboardCard from "./DashboardCard";
import PointsTable from "./PointsTable";
import { useEffect, useState } from "react";
import axios from "axios";

const DashBoard = () => {
  const [data, setData] = useState(null);
  const [tableData,setTableData] = useState(null);
  console.log(tableData);
  useEffect(() => {
    const { id } = JSON.parse(localStorage.getItem("user"));
    const getData = async () => {
      const response = await axios.get(`http://localhost:3000/utils/${id}`, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      setData(response.data);
    };

    const getTopSubscribers = async () => {
      const response = await axios.get("http://localhost:3000/topsubscribers", {
        headers: {
          "Content-Type": "application/json",
        },
      });
      console.log(response)
      setTableData(response.data.data);
    };
    getTopSubscribers();
    getData();
  }, []);
  return (
    <main className="flex-1 px-3 ">
      <section className="flex flex-col lg:grid lg:grid-cols-3 gap-6 mb-4justify-between">
        <DashboardCard
          heading={"Total Points"}
          text={"Points earned by subscriptions"}
          value={data?.points || 0}
          color={"red"}
        />
        <DashboardCard
          heading={"Books Subscribed"}
          text={"Number of books read by user"}
          value={data?.booksSubscribed || 0}
          color={"blue"}
          data={data}
        />
        <Link to={"/subscriptions"}>
          <DashboardCard
            heading={"Active Subscriptions"}
            text={"Number of books currently reading"}
            value={data?.activeSubscriptionsCount || 0}
            color={"green"}
          />
        </Link>
        <PointsTable data={tableData} />
        <Chart />
      </section>
    </main>
  );
};

export default DashBoard;
