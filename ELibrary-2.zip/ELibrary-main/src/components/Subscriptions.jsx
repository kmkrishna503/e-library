import axios from "axios";
import React, { useEffect, useState } from "react";

import ActiveSubscriptions from "./ActiveSubscriptions";
import HistoricalSubscriptions from "./HistoricalSubscriptions";

const Subscriptions = () => {
  const [activeSubscriptions, setActiveSubscriptions] = useState([]);
  const [inactiveSubscriptions, setInactiveSubscriptions] = useState([]);
  console.log(activeSubscriptions);
  useEffect(() => {
    const getSubscriptions = async () => {
      const { id } = JSON.parse(localStorage.getItem("user"));
      const response = await axios.get(
        `http://localhost:3000/subscriptions/${id}`,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      const { activeSubscriptions, inactiveSubscriptions } = response.data;
      setActiveSubscriptions(activeSubscriptions);
      setInactiveSubscriptions(inactiveSubscriptions);
    };
    getSubscriptions();

  }, []);

  return (
    <div className="px-3 flex flex-col gap-10">
      <ActiveSubscriptions data={activeSubscriptions} />
      <HistoricalSubscriptions data={inactiveSubscriptions} />
    </div>
  );
};

export default Subscriptions;
