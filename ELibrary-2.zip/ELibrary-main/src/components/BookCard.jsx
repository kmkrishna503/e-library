/* eslint-disable react/prop-types */
import { Button, Card, CardBody, CardHeader } from "@material-tailwind/react";
import { Link } from "react-router-dom";

const BookCard = ({ id, title, author, category, image }) => {
  return (
    <Card className="bg-gray-900 text-white">
      <CardHeader
        floated={false}
        shadow={false}
        className="font-semibold text-lg bg-inherit text-inherit"
      >
        {title}
      </CardHeader>
      <CardBody className="flex justify-between items-center">
        <section className="">
          <p>Author : {author}</p>
          <p>Category : {category}</p>
          <div className="flex justify-between gap-3 items-center mt-2">
            <Link
              to={`/books/${id}`}
              className=" cursor-pointer text-blue-300 hover:underline transition-all duration-300 ease-in-out"
            >
              Preview
            </Link>
            <Link
              to={`/subscription/${id}`}
              className=" cursor-pointer text-blue-300 hover:underline transition-all duration-300 ease-in-out"
            >
              Subscribe
            </Link>
          </div>
        </section>
        <section>
          <img src={image} alt={title} className="h-32 w-32 object-cover" />
        </section>
      </CardBody>
    </Card>
  );
};

export default BookCard;
