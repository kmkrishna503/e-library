import { Button, Input, Typography } from "@material-tailwind/react";
import { Link, useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import axios from "axios";
import { toast } from "react-toastify";
const Register = () => {
  const navigate = useNavigate();
  const form = useForm();
  const { register, handleSubmit, formState, clearErrors } = form;
  const { errors } = formState;
  const errorMessages = Object.values(errors);

  if (errorMessages.length !== 0) {
    const obj1 = errorMessages[0];
    toast.error(errorMessages[0]?.message || Object.values(obj1)[0].message);
    clearErrors();
  }
  const handleRegisteration = async (data) => {
    try {
      const response = await axios.post(
        "http://localhost:3000/register",
        data,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      if (response.status === 200) {
        toast.success(response.data.message);
        navigate("/login", { replace: true });
      }
    } catch (err) {
      toast.error(err.response.data.message);
    }
  };
  return (
    <div className="min-h-screen flex items-center justify-center w-screen border border-black">
      <div className="p-4 w-full max-w-xs sm:max-w-sm md:max-w-md lg:max-w-md rounded-lg shadow-md bg-primary ">
        <form
          className="flex flex-col gap-6 "
          onSubmit={handleSubmit(handleRegisteration)}
        >
          <Typography as="h1" className="font-bold text-2xl text-center">
            Sign Up
          </Typography>
          <Input
            type="text"
            label="Name"
            variant="outlined"
            {...register("name", {
              required: {
                value: true,
                message: "User name is required !",
              },
            })}
          />
          <Input
            label="Email"
            type="email"
            variant="outlined"
            {...register("email", {
              required: {
                value: true,
                message: "User email is required !",
              },
            })}
          />
          <Input
            label="Password"
            type="password"
            variant="outlined"
            {...register("password", {
              required: {
                value: true,
                message: "User password is required !",
              },
            })}
          />

          <Button type="submit" variant="contained">
            Register
          </Button>
          <Typography>
            Already have a account ?{" "}
            <span className="text-orange-500 font-bold text-lg">
              <Link to={"/login"}>Login</Link>
            </span>
          </Typography>
        </form>
      </div>
    </div>
  );
};

export default Register;
