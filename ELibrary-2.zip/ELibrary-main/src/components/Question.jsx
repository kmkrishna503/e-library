/* eslint-disable react/prop-types */
import { Button } from "@material-tailwind/react";
import { ArrowLeftIcon, ArrowRightIcon } from "@heroicons/react/24/solid";
const Question = ({
  question,
  index,
  register,
  currentQuestion,
  setCurrentQuestion,
}) => {
  console.log(currentQuestion);
  return (
    <>
      <div className={`${currentQuestion === index + 1 ? "block" : "hidden"}`}>
        <p>
          {index + 1} {question?.question}
        </p>
        <div className="grid grid-cols-4 md:grid-cols-2 lg:grid-cols-8 mt-3 items-center">
          {question?.options.map((option, optionIndex) => {
            return (
              <>
                <input
                  type="radio"
                  key={optionIndex}
                  name={question.question} // Use a unique name for each option
                  label={option}
                  value={option}
                  {...register(question.questionId)}
                  className="h-4"
                />
                {option}
              </>
            );
          })}
        </div>
        {console.log(currentQuestion === 3)}
        <div className="flex items-center justify-between mt-10">
          <Button
            onClick={() => setCurrentQuestion(currentQuestion - 1)}
            className={`flex items-center gap-3 `}
            disabled={currentQuestion === 1}
          >
            <ArrowLeftIcon className="h-5 w-5 font-bold" />
            Previous
          </Button>
          <Button
            onClick={() => setCurrentQuestion(currentQuestion + 1)}
            className={`flex items-center gap-3`}
            disabled={currentQuestion === 3}
          >
            Next
            <ArrowRightIcon className="h-5 w-5 font-bold" />
          </Button>
        </div>
      </div>
    </>
  );
};

export default Question;
