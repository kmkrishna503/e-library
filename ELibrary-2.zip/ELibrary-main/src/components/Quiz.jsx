/* eslint-disable react/prop-types */
import axios from "axios";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Button, Card } from "@material-tailwind/react";
import Question from "./Question";
import { ArrowPathIcon } from "@heroicons/react/24/solid";
const Quiz = ({ bookId }) => {
  const [currentQuestion, setCurrentQuestion] = useState(1);
  const form = useForm({
    mode: "onChange",
  });
  const { register, handleSubmit, formState, reset } = form;
  const { isSubmitSuccessful } = formState;
  const [questions, setQuestions] = useState([]);
  const [score, setScore] = useState(0);
  const getQuizQuestions = async () => {
    const res = await axios.get(
      `http://localhost:3000/quiz/questions/${bookId}`
    );
    setQuestions(res.data.questions);
  };
  useEffect(() => {
    getQuizQuestions();
  }, [bookId]);

  const evaluateQuiz = async (data) => {
    const answers = Object.values(data);
    const correctAnswers = questions.map((item) => item.correctAnswer);
    let correctMatches = 0;
    for (let i = 0; i < answers.length; i++) {
      if (answers[i] === correctAnswers[i]) {
        correctMatches++;
      }
    }
    console.log(correctMatches);
    setScore(correctMatches * 10);
  };

  if (isSubmitSuccessful) {
    return (
      <div className="flex items-center justify-center p-10">
        <Card className="p-10 text-black">
          <p className="font-semibold text-xl">Submit Successful</p>
          <p>Your Score : {score}</p>
          <Button
            className="mt-4 flex items-center justify-around"
            onClick={() => {
              reset();
              setCurrentQuestion(1);
            }}
          >
            Try Again !
            <ArrowPathIcon className="h-6 w-6" />
          </Button>
        </Card>
      </div>
    );
  }
  return (
    <Card className="my-5 pb-5">
      <div className="">
        <p className="text-center text-black font-semibold text-lg my-4">
          Quiz Questions
        </p>
      </div>
      <div className="px-6">
        <form
          onSubmit={handleSubmit(evaluateQuiz)}
          className="flex flex-col gap-10"
        >
          {questions?.map((item, index) => {
            return (
              <Question
                currentQuestion={currentQuestion}
                question={item}
                key={index}
                index={index}
                register={register}
                setCurrentQuestion={setCurrentQuestion}
              />
            );
          })}

          <Button type="submit" className="w-fit mx-auto">
            Submit Quiz
          </Button>
        </form>
      </div>
    </Card>
  );
};

export default Quiz;
