import { Navigate, Outlet } from "react-router-dom";
import NavBar from "../components/NavBar";
import { SideBar } from "../components/SideBar";

const RequireAuth = () => {
  const isLoggedIn = localStorage.getItem("isLoggedIn");
  console.log(isLoggedIn)
  return isLoggedIn ? (
    <>
      <NavBar />
      <SideBar />
      <div className="lg:ml-[16rem] pt-[5rem]">
        <Outlet />
      </div>
    </>
  ) : (
    <Navigate to={"/login"} replace />
  );
};

export default RequireAuth;
