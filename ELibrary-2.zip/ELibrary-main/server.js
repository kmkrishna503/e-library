import jsonServer from "json-server";
const server = jsonServer.create();
const router = jsonServer.router("./E_books.json");
const middlewares = jsonServer.defaults();
import bodyParser from "body-parser"; // Add this line
import cors from "cors";
server.use(cors());
server.use(bodyParser.json());

server.post("/register", (req, res) => {
  const { name, email, password } = req.body;
  const users = router.db.get("users").value();
  const nextUserId =
    users?.length > 0 ? Math.max(...users.map((u) => u.id)) + 1 : 1;
  const userExists = users?.find((u) => u.email === email);
  if (userExists) {
    return res.status(409).json({ message: "user already registered !" });
  }
  const newUser = { id: nextUserId, name, email, password };
  router.db.get("users").push(newUser).write();
  res.status(200).json({ message: "Registration successful", user: newUser });
});

server.post("/login", async (req, res) => {
  const { email, password } = req.body;
  const users = await router.db.get("users").value();
  const user = users?.find(
    (user) => user.email === email && user.password === password
  );
  console.log(user);
  if (user) {
    res.status(200).json({ message: "Login successful", user });
  } else {
    res.status(401).json({ message: "Invalid credentials" });
  }
});

server.get("/quiz/questions/:bookId", async (req, res) => {
  const { bookId } = req.params;
  if (!bookId || !Number(bookId)) {
    return res.status(400).json({ message: "Book Id not found" });
  }
  const allQuestions = router.db.get("questions").value();
  const bookQuestions = allQuestions.find((item) => item.bookId === bookId);
  return res.status(200).json({
    message: "Quiz questions sent",
    questions: bookQuestions["questions"],
  });
});

server.post("/subscribe", async (req, res) => {
  console.log(req.body);
  const userSubscriptions = router.db.get("userSubscriptions").value();
  const nextSubscripitionId =
    userSubscriptions?.length > 0
      ? Math.max(...userSubscriptions.map((u) => u.subscriptionId)) + 1
      : 1;
  req.body.subscriptionId = nextSubscripitionId;
  router.db.get("userSubscriptions").push(req.body).write();
  return res.status(201).json({ message: "Subscribed to book !" });
});

server.get("/subscriptions/:userid", async (req, res) => {
  const userid = req.params.userid;
  if (!Number(userid)) {
    return res.status(400).json({ message: "Invalid user id" });
  }
  const subscriptions = router.db.get("userSubscriptions").value();
  const userSubscriptions = subscriptions.filter(
    (item, index) => item.userId == userid
  );
  const oneMonthInMilliseconds = 30 * 24 * 60 * 60 * 1000; // Assuming 30 days in a month
  const currentDate = new Date();
  const data = userSubscriptions.map((item) => {
    const joiningDate = new Date(item.joiningDate);
    const expirationDate = new Date(
      joiningDate.getTime() + oneMonthInMilliseconds
    );
    return {
      ...item,
      isActive: expirationDate > currentDate,
      expirationDate: expirationDate,
    };
  });

  const activeSubscriptions = data.filter((item) => item.isActive);
  const inactiveSubscriptions = data.filter((item) => !item.isActive);
  return res.status(200).json({
    message: "User subscriptions sent !",
    activeSubscriptions,
    inactiveSubscriptions,
  });
});

server.get("/utils/:userId", async (req, res) => {
  const { userId } = req.params;
  const allSubscriptions = router.db.get("userSubscriptions").value();
  const userSubscriptions = allSubscriptions.filter((item, index) => {
    return item.userId == userId;
  });
  const points = userSubscriptions.reduce((total, curr) => {
    return total + Number(curr.points);
  }, 0);

  const booksSubscribed = userSubscriptions?.length || 0;

  const oneMonthInMilliseconds = 30 * 24 * 60 * 60 * 1000; // Assuming 30 days in a month
  const currentDate = new Date();
  const data = userSubscriptions.map((item) => {
    const joiningDate = new Date(item.joiningDate);
    const expirationDate = new Date(
      joiningDate.getTime() + oneMonthInMilliseconds
    );
    return {
      ...item,
      isActive: expirationDate > currentDate,
      expirationDate: expirationDate,
    };
  });

  const activeSubscriptions = data.filter((item) => item.isActive);
  const activeSubscriptionsCount = activeSubscriptions.length;
  return res.status(200).json({message : "Dashboard Data sent !",points,booksSubscribed,activeSubscriptionsCount});
});


server.get("/topsubscribers",async(req,res)=>{
  const subscriptions = router.db.get("userSubscriptions").value();
  const groupedData = subscriptions.reduce((acc, obj) => {
    const subscriberName = obj.name;
    if (!acc[subscriberName]) {
      acc[subscriberName] = { name: subscriberName, totalPoints: 0 };
    }
    acc[subscriberName].totalPoints += parseInt(obj.points, 10) || 0;
    return acc;
  }, {});
  
  // Step 2: Convert grouped data to an array
  const subscriberArray = Object.values(groupedData);
  
  // Step 3: Sort by total points in descending order
  subscriberArray.sort((a, b) => b.totalPoints - a.totalPoints);

  return res.status(200).json({message : "Top subscribers data sent !",data : subscriberArray})
  
})

// Apply middleware and use router
server.use(middlewares);
server.use(jsonServer.bodyParser);
server.use(router);

// Start server
const port = 3000;
server.listen(port, () => {
  console.log(`JSON Server is running on http://localhost:${port}`);
});
