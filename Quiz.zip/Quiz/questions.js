import React, { useState } from "react";
import "./questions.css";

export default function Question(props) {
  const questions = [
    {
      questionText:
        "Which function is used to serialize an object into a JSON string in Javascript?",
      answerOptions: [
        { answerText: "A stringify", isCorrect: true },
        { answerText: "B convert()", isCorrect: false },
        { answerText: "C parse()", isCorrect: false },
        { answerText: "D None of the above", isCorrect: false },
      ],
    },
    {
      questionText:
        "Which of the following keywords is used to define a variable in Javascript?",
      answerOptions: [
        { answerText: "A var", isCorrect: false },
        { answerText: "B let", isCorrect: false },
        { answerText: "C var and let", isCorrect: true },
        { answerText: "D None of the above", isCorrect: false },
      ],
    },
    {
      questionText:
        "Which of the following methods can be used to display data in some form using Javascript?",
      answerOptions: [
        { answerText: "A document.write()", isCorrect: false },
        { answerText: "B console.log()", isCorrect: false },
        { answerText: "C window.alert", isCorrect: false },
        { answerText: "D All of the above", isCorrect: true },
      ],
    },
    {
      questionText: "How can a datatype be declared to be a constant type?",
      answerOptions: [
        { answerText: "A const", isCorrect: true },
        { answerText: "B var", isCorrect: false },
        { answerText: "C let", isCorrect: false },
        { answerText: "D constant", isCorrect: false },
      ],
    },
    {
      questionText: "What is the capital of France?",
      answerOptions: [
        { answerText: "A New York", isCorrect: false },
        { answerText: "B London", isCorrect: false },
        { answerText: "C Paris", isCorrect: true },
        { answerText: "D Dublin", isCorrect: false },
      ],
    },
    {
      questionText: "Who is CEO of Tesla?",
      answerOptions: [
        { answerText: "A Jeff Bezos", isCorrect: false },
        { answerText: "B Elon Musk", isCorrect: true },
        { answerText: "C Bill Gates", isCorrect: false },
        { answerText: "D Tony Stark", isCorrect: false },
      ],
    },
    {
      questionText: "The iPhone was created by which company?",
      answerOptions: [
        { answerText: "A Apple", isCorrect: true },
        { answerText: "B Intel", isCorrect: false },
        { answerText: "C Amazon", isCorrect: false },
        { answerText: "D Microsoft", isCorrect: false },
      ],
    },
    {
      questionText: "How many Harry Potter books are there?",
      answerOptions: [
        { answerText: "A 1", isCorrect: false },
        { answerText: "B 4", isCorrect: false },
        { answerText: "C 6", isCorrect: false },
        { answerText: "D 7", isCorrect: true },
      ],
    },
  ];

  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [showScore, setShowScore] = useState(false);
  const [score, setScore] = useState(0);

  const handleAnswerOptionClick = (isCorrect) => {
    if (isCorrect) {
      setScore(score + 1);
    }

    const nextQuestion = currentQuestion + 1;
    if (nextQuestion < questions.length) {
      setCurrentQuestion(nextQuestion);
    } else {
      setShowScore(true);
    }
  };
  const resetQuiz = () => {
    setShowScore(false);
    setCurrentQuestion(0);
    setScore(0);
  };
  return (
    <div className="app-quiz">
      {showScore ? (
        <>
          <div className="score-section">
            You scored {score} out of {questions.length}
          </div>
          <button onClick={resetQuiz} className="btnQuiz">
            Again Quiz
          </button>
        </>
      ) : (
        <>
          <div className="question-section">
            <div className="question-count">
              <span>Question {currentQuestion + 1}</span>/{questions.length}
            </div>
            <div className="question-text">
              {questions[currentQuestion].questionText}
            </div>
          </div>
          <div className="answer-section">
            {questions[currentQuestion].answerOptions.map((answerOption) => (
              <button
                onClick={() => handleAnswerOptionClick(answerOption.isCorrect)}
              >
                {answerOption.answerText}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
