import * as React from "react";
import { styled } from "@mui/material/styles";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import "./quiz.css";
import Question from "./questions";
import HourglassEmptyOutlinedIcon from "@mui/icons-material/HourglassEmptyOutlined";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

function createData(id, name, subsDate, subsId) {
  return { id, name, subsDate, subsId };
}

const rows = [
  createData("1", "Harry Potter & the half blood", "23/02/2022", "20133"),
  createData("4", "Interstellar", "15/02/2023", "12355"),
];

export default function Quiz() {
  const [quiz, setQuiz] = React.useState(false);

  const handleQuiz = () => {
    setQuiz(!quiz);
  };
  return (
    <>
      <div
        style={{
          border: "1px solid black",
          padding: "25px 15px",
          borderRadius: "20px",
          boxShadow: "rgba(0, 0, 0, 0.35) 0px 5px 15px",
        }}
      >
        <h6 className="text-muted text-center ">
          Select From Your Active Subscription
        </h6>
        <TableContainer className="quiz" component={Paper}>
          <Table sx={{ minWidth: 700 }} aria-label="customized table">
            <TableHead>
              <TableRow>
                <StyledTableCell>E-book id</StyledTableCell>
                <StyledTableCell align="left">e-Book Name</StyledTableCell>
                <StyledTableCell align="left">
                  Subscription Data​
                </StyledTableCell>
                <StyledTableCell align="left">Subscription Id​</StyledTableCell>
                <StyledTableCell align="left">&nbsp;</StyledTableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {rows.map((row) => (
                <StyledTableRow key={row.id}>
                  <StyledTableCell component="th" scope="row">
                    {row.id}
                  </StyledTableCell>
                  <StyledTableCell align="left">{row.name}</StyledTableCell>
                  <StyledTableCell align="left">{row.subsDate}</StyledTableCell>
                  <StyledTableCell align="left">{row.subsId}</StyledTableCell>
                  <StyledTableCell align="left">
                    <HourglassEmptyOutlinedIcon
                      onClick={handleQuiz}
                      id="icon"
                    />
                  </StyledTableCell>
                </StyledTableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        {/* */}
      </div>
      {quiz && <Question />}
    </>
  );
}
