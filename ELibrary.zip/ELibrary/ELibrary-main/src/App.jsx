import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./components/Login";
import Register from "./components/Register";
import Home from "./components/Home";
import Logout from "./components/Logout";
import DashBoard from "./components/DashBoard";
import EBooks from "./components/EBooks";
import Book from "./components/Book";
import Subscriptions from "./components/Subscriptions";
import Subscription from "./components/Subscription";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import RequireAuth from "./features/RequireAuth";
// import Welcome from "./components/Welcome";
// import Home from "./components/Home";
// import Profile from "./components/Profile";

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        {/* <Route path="/" element={<Welcome />} /> */}
        <Route path="/" element={<RequireAuth />}>
          <Route index element={<DashBoard />} />
          <Route path="ebooks" element={<EBooks />} />
          <Route path="subscriptions" element={<Subscriptions />} />
          <Route path="books/:id" element={<Book />}></Route>
          <Route path="subscription/:id" element={<Subscription />} />
        </Route>

        <Route path="/login" element={<Login />} />
        <Route path="/logout" element={<Logout />} />
        <Route path="/register" element={<Register />} />
        {/* <Route path="/profile" element={<Profile />} /> */}
      </Routes>
      <ToastContainer />
    </BrowserRouter>
  );
};

export default App;
