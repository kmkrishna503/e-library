import { Input, Button, Card } from "@material-tailwind/react";
import { useEffect, useState } from "react";
import axios from "axios";
import BookCard from "./BookCard";
const EBooks = () => {
  const [books, setBooks] = useState([]);
  const [filteredBooks, setFilteredBooks] = useState([]);
  useEffect(() => {
    const fetchData = async () => {
      const response = await axios.get("http://localhost:3000/books");
      console.log(response);
      const data = await response.data;
      setBooks(data);
      setFilteredBooks(data);
    };
    fetchData();
  }, []);

  const handleFilterByName = (e) => {
    const filteredBooks = books.filter((book) => {
      return book.name.toLowerCase().includes(e.target.value.toLowerCase());
    });
    console.log(filteredBooks);
    setFilteredBooks(filteredBooks);
  };

  const handleFilterByCategory = (e) => {
    const filteredBooks = books.filter((book) => {
      return book.Category.toLowerCase().includes(e.target.value.toLowerCase());
    });
    console.log(filteredBooks);
    setFilteredBooks(filteredBooks);
  };

  const handleFilterByAuthor = (e) => {
    const filteredBooks = books.filter((book) => {
      return book.author.toLowerCase().includes(e.target.value.toLowerCase());
    });
    console.log(filteredBooks);
    setFilteredBooks(filteredBooks);
  };
  return (
    <main className="w-full px-3">
      <Card className="flex flex-col gap-7 p-4 md:p-6">
        <h1 className="text-lg text-gray-800 font-semibold text-center">
          E-Book Filters
        </h1>
        <div>
          <form className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 justify-between items-center">
            <Input
              type="text"
              label="Search By Name"
              onChange={handleFilterByName}
            />
            <Input
              type="text"
              label="Search By Category"
              onChange={handleFilterByCategory}
            />
            <Input
              type="text"
              label="Search By Author"
              onChange={handleFilterByAuthor}
            />
            <Button type="reset" onClick={() => setFilteredBooks(books)}>Reset</Button>
          </form>
        </div>
      </Card>
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mt-10">
        {filteredBooks?.map((book, index) => {
          return (
            <BookCard
              key={index}
              id={book.id}
              title={book.name}
              author={book.author}
              category={book.Category}
              image={book.img}
            />
          );
        })}
      </section>
    </main>
  );
};

export default EBooks;
