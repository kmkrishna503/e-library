import NavBar from "./NavBar";
import { Outlet } from "react-router-dom";
import { SideBar } from "./SideBar";

const Home = () => {
  return (
    <>
      <NavBar />
      <SideBar />
      <div className="lg:ml-[16rem] pt-16">
        <Outlet/>
      </div>
    </>
  );
};

export default Home;
