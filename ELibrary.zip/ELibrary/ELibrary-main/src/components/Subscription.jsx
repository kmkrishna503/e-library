import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  Input,
} from "@material-tailwind/react";
const Subscription = () => {
  const { id } = useParams();
  const [book, setBook] = useState();
  const [showSubscription, setShowSubscription] = useState(false);
  useEffect(() => {
    const getBook = async () => {
      const response = await axios.get(`http://localhost:3000/books/${id}`);
      const book = await response.data;
      setBook(book);
    };
    getBook();
  }, [id]);
  return (
    <div>
      <section className="w-full px-3">
        <Card className="w-full px-3">
          <CardHeader
            floated={false}
            shadow={false}
            className="font-semibold text-lg bg-inherit text-inherit text-center"
          >
            {book?.name} (Subscription)
          </CardHeader>
          <CardBody className="grid grid-cols-4 text-white items-center justify-center  bg-gray-900 p-4 rounded-md">
            <section className="font-medium flex gap-2 flex-col">
              <p>Author : {book?.author}</p>
              <p>Category : {book?.Category}</p>
              <p>Publisher : {book?.Publisher}</p>
              <p>Date Published : {book?.["Date Published"]}</p>
              <p>Points : {book?.points}</p>
            </section>
            <section className="col-span-2 flex flex-col justify-between">
              Harry Potteris a series of sevenfantasy novelswritten by British
              author J. K. Rowling. The novels chronicle the lives of a
              youngwizard,Harry Potter, and his friendsHermione GrangerandRon
              Weasley, all of whom are students atHogwarts School of Witchcraft
              and Wizardry. The mainstory arcconcerns Harry's struggle
              againstLord Voldemort, a dark wizard who intends to become
              immortal, overthrow the wizard governing body known as theMinistry
              of Magicand subjugate all wizards andMuggles(non-magical people).
              <div className="flex w-full justify-between items-center">
                <p
                  className="p-2 cursor-pointer text-blue-300 hover:underline transition-all duration-300 ease-in-out"
                  onClick={() => setShowSubscription(!showSubscription)}
                >
                  {showSubscription ? "Hide Subscription" : "Subscribe"}
                </p>
              </div>
            </section>
            <section>
              <img
                src={book?.img}
                alt={book?.name}
                className="h-60 w-full object-contain"
              />
            </section>
          </CardBody>
        </Card>
        <Card
          className={`mt-5 text-black py-4 ${
            showSubscription ? "block" : "hidden"
          }`}
        >
          <CardHeader
            floated={false}
            shadow={false}
            className="font-semibold text-lg bg-inherit text-inherit text-center"
          >
            {book?.name} (Subscription Form)
          </CardHeader>
          <CardBody>
            <form
              action=""
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-5 gap-y-6 items-center"
            >
              <div>
                <label htmlFor="Global ID">Global ID</label>
                <Input type="text" label="Enter Global ID" />
              </div>
              <div>
                <label htmlFor="joiningDate">Joining Date</label>
                <Input type="date" />
              </div>
              <div>
                <label htmlFor="Name">Name</label>
                <Input type="text" name="name" />
              </div>
              <div>
                <label htmlFor="empId">Employee ID</label>
                <Input type="number" />
              </div>
              <div>
                <label htmlFor="Grade">Grade</label>
                <Input type="text" />
              </div>
              <div>
                <label htmlFor="Supervisior">Supervisor</label>
                <Input type="text" />
              </div>
              <Button type="submit" className="place-self-center col-span-3">
                Save & Download
              </Button>
            </form>
          </CardBody>
        </Card>
      </section>
    </div>
  );
};

export default Subscription;
